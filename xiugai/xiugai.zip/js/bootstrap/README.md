Bootstrap
=========

Shim repository for [Bootstrap](http://getbootstrap.com).

[![](http://spmjs.io/badge/bootstrap)](http://spmjs.io/package/bootstrap)

