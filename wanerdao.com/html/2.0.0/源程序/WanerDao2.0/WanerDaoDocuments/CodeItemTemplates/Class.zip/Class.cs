﻿#region Version Info 
/* ======================================================================== 
* 【本类功能概述】 
* 
* 作者：杨晓东   时间：$time$ 
* 文件名：$safeitemname$ 
* 版本：V1.0.1 
* 
* 修改者： 时间： 
* 修改说明： 
* ======================================================================== 
*/ 
#endregion

using System;
using System.Collections.Generic;
$if$ ($targetframeworkversion$ >= 3.5)using System.Linq;
$endif$using System.Text;

namespace $rootnamespace$
{
	class $safeitemrootname$
	{
	}
}
