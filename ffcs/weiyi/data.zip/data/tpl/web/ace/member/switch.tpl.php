<?php defined('IN_IA') or exit('Access Denied');?><?php  include template('common/header', TEMPLATE_INCLUDEPATH);?>
<?php  echo $script;?>
<?php  include template('common/footer', TEMPLATE_INCLUDEPATH);?>
