<?php defined('IN_IA') or exit('Access Denied');?>
<!-- PAGE CONTENT ENDS -->
</div><!-- /.col -->
</div><!-- /.row -->
</div><!-- /.page-content -->
</div><!-- /.main-content -->
</div><!-- /.main-container-inner -->

<!-- basic scripts -->

<script type="text/javascript">
    if("ontouchend" in document) document.write("<script src='./resource/ace/assets/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
</script>
<script src="./resource/ace/assets/js/bootstrap.min.js"></script>
<script src="./resource/ace/assets/js/jquery.cookie.min.js"></script>
<script src="./resource/ace/assets/js/typeahead-bs2.min.js"></script>

<!-- page specific plugin scripts -->

<!-- ace scripts -->

<script src="./resource/ace/assets/js/ace-elements.min.js"></script>
<script src="./resource/ace/assets/js/ace.min.js"></script>

<!-- inline scripts related to this page -->
<!--<div id="footer">
    <span class="pull-left">
        <p>Powered by <a href="http://www.ffcs.cn" target="_blank"><b>FFCS</b></a> v<?php echo IMS_VERSION;?> &copy; 2013 <a href="http://www.ffcs.cn" target="_blank">www.ffcs.cn</a></p>
    </span>
    <span class="pull-right">
        <p><a href="http://www.ffcs.cn" target="_blank">关于福富</a></p>
    </span>
</div>-->
<div class="emotions" style="display:none;"></div>
</body>
</html>
