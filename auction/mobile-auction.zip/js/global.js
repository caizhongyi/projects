$(function(){
 /*   $(document).on('click','a',function(){
        $(this).text('努力加载中...');
    }).on('click','[data-loading-text]',function(){
        $(this).attr('disabled').val(($(this).attr('data-loading-text') || 'loading') + '...');
    });*/
});