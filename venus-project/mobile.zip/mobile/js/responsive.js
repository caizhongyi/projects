var viewportElement, styleElement;

function removeElement(_element){
    if( !_element ) return ;
    var _parentElement = _element.parentNode;
    if(_parentElement){
        _parentElement.removeChild(_element);
    }
}
function prependChild(parent,newChild){
    if(parent.firstChild){
        parent.insertBefore(newChild,parent.firstChild);
    } else {
        parent.appendChild(newChild);
    }
    return parent;
}

function viewport(){

    var head = document.getElementsByTagName('head');

    removeElement(viewportElement);
    removeElement(styleElement);

    viewportElement = document.createElement('meta');
    styleElement = document.createElement('style');

    console.log(window.devicePixelRatio);

    var dpr = window.devicePixelRatio, scale = 1 / dpr;
    var size = dpr * window.screen.width / 10;
    viewportElement.name = "viewport";
    viewportElement.setAttribute("content" , 'initial-scale='+ scale +',maximum-scale='+ scale +',minimum-scale='+ scale +',user-scalable=no,width=device-width') ;
    styleElement.innerHTML = 'html{ font-size:'+ size +'px; }';
    prependChild( head[0] , styleElement);
    prependChild( head[0] , viewportElement);

}
window.addEventListener('resize',function(){
    viewport()
})
viewport();