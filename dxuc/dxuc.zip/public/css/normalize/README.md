normalize
===============

A normalize.css plugin


Install
-------

Install with npm:

    $ npm install normalize

Usage
-----


For more details please visit [中文文档](https://www.alienjs.net)
