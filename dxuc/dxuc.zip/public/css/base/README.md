aliencss-common
===============

A aliencss-common.css plugin


Install
-------

Install with npm:

    $ npm install aliencss-common

Usage
-----

```css
    .pull-left
    .pull-right
    .grayscale
    .nowrap
    .inline-block
    .center-block
    .unstyled
    .center-box
    .links
    .sitemap
    .section
    .section-sub
    .bg-cover
    .image-preivew
    .clear
    .clearfix
    .bold
    .italic
    .rounded
    .soften
    
    .hide
    .show
    .visible
    .hidden
    .in
```

For more details please visit [中文文档](https://www.alienjs.net)
